package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;
import app.akexorcist.bluetotohspp.library.BluetoothState;
import app.akexorcist.bluetotohspp.library.DeviceList;

public class MainActivity extends AppCompatActivity
{

    private BluetoothSPP bt;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt = new BluetoothSPP(this);

        if (!bt.isBluetoothAvailable())                                                             //블루투스 사용 불가
        {
            Toast.makeText(getApplicationContext(), "블루투스 사용 불가", Toast.LENGTH_SHORT).show();
            finish();
        }

        /*bt.setOnDataReceivedListener(new BluetoothSPP.OnDataReceivedListener()                      //아두이노 에서 넘어오는 데이터 수신
        {
            public void onDataReceived(byte[] data, String message)
            {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });*/

        bt.setBluetoothConnectionListener(new BluetoothSPP.BluetoothConnectionListener()            //연결됐을 때
        {
            public void onDeviceConnected(String name, String address)
            {
                Toast.makeText(getApplicationContext(), "연결됨 -> " + name + "\n" + address, Toast.LENGTH_SHORT).show();
            }

            public void onDeviceDisconnected()                                                      //연결해제
            {
                Toast.makeText(getApplicationContext(), "연결 해제", Toast.LENGTH_SHORT).show();
            }

            public void onDeviceConnectionFailed()                                                  //연결실패
            {
                Toast.makeText(getApplicationContext(), "연결 실패", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnConnect = findViewById(R.id.btnConnect);                                          //연결시도
        btnConnect.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (bt.getServiceState() == BluetoothState.STATE_CONNECTED)
                {
                    bt.disconnect();
                }
                else
                {
                    Intent intent_DeviceList = new Intent(getApplicationContext(), DeviceList.class);startActivityForResult(intent_DeviceList, BluetoothState.REQUEST_CONNECT_DEVICE);
                }
            }
        });
    }

    public void onDestroy()
    {
        super.onDestroy();
        bt.stopService();                                                                           //블루투스 중지

    }

    public void onStart()
    {
        super.onStart();
        if (!bt.isBluetoothEnabled())
        {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, BluetoothState.REQUEST_ENABLE_BT);
        }
        else
        {
            if (!bt.isServiceAvailable())
            {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER);
                setup();
            }
        }
    }

    public void setup()
    {
        Button btnSend = findViewById(R.id.btnSetting);                                                //블루투스 서비스가 된 후
        btnSend.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Intent intent_setting = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(intent_setting);
                int senddata_r = intent_setting.getIntExtra("data_r",0);
                int senddata_g = intent_setting.getIntExtra("data_g",0);
                int senddata_b = intent_setting.getIntExtra("data_b",0);
                byte[] totaldata = new byte[3];
                totaldata[0] = (byte) (senddata_r >> 24);
                totaldata[1] = (byte) (senddata_g >> 16);
                totaldata[2] = (byte) (senddata_b >> 8);

                bt.send(totaldata, true);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BluetoothState.REQUEST_CONNECT_DEVICE)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                bt.connect(data);
            }
        }
        else if (requestCode == BluetoothState.REQUEST_ENABLE_BT)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER);
                setup();
            }
            else
            {
                Toast.makeText(getApplicationContext(), "블루 투스 연결 안됨.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
}